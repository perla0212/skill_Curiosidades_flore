const Alexa = require('ask-sdk-core');
const i18n = require('i18next');
const sprintf = require('i18next-sprintf-postprocessor');
const persistence = require('./persistence');

let DOCUMENT_ID = "";
const info = require('./flores');

let DataSource = {
    "mensaje": {
        "encabezado": "",
        "by": "",
        "titulo": "",
        "msj": "",
        "footer": ""
    }
};

let infoSources = DataSource.mensaje;
let name ='';
let significado ='';
//-------------------------------------------------descripcion español------------------------------------------------------------------------------------------------------------------------------
const DescripcionTable = {
    "rosa": [
        "Rosa. Es un género que está compuesto por un conocido grupo de arbustos espinosos y floridos representantes principales de la familia de las rosáceas.",
        "El rosal es una de las plantas más populares de los jardines, incluso existen jardines específicos llamados rosaledas",
    ],
    "tulipan": [
        "Tulipa es un género de plantas perennes y bulbosas perteneciente a la familia Liliaceae, en el que se incluyen los populares tulipanes",
        "El género Tulipa comprende aproximadamente unas 150 especies originarias, principalmente de las regiones montañosas de Asia Menor, Persia, el Cáucaso, Turquía y Bukhara.",
    ],
    "girasol":[
        "El girasol tiene un tallo robusto, erguido, con pelitos y hojas ovaladas de gran tamaño.",
        "La flor del girasol puede medir entre 5 y 40 centímetros de ancho.",
  
    ],

}
//---------------------------------------------significado español---------------------------------------------------------------------------------------------------------------------------------
const SignificadoTable = {
    "rosa": [
        "La rosa símbolo de simpatía, franqueza y amabilidad.",
        "Simbolizar aprecio, confianza y agradecimiento",
    ],
    "tulipan": [
        "El tulipán es un símbolo de amor sincero.",
        "Es el significado del afecto, alegría",
        
    ],
    "girasol":[
        "El girasol es el símbolo del Sol y simboliza el amor y la admiración",
        "El girasol significa la felicidad, la vitalidad, el positivismo y la energía",
  
    ],

}
//-------------------------------------------------descripcion ingles------------------------------------------------------------------------------------------------------------------------------
const DescriptionEnglish = {
    "rosa": [
        "Rosa. It is a genus that is made up of a well-known group of thorny and flowering shrubs that are the main representatives of the Rosaceae family.",
        "The rose bush is one of the most popular plants in gardens, there are even specific gardens called rose gardens",
    ],
    "tulipan": [
        "Tulipa is a genus of perennial and bulbous plants belonging to the Liliaceae family, which includes the popular tulips",
        "The genus Tulipa comprises approximately 150 species originating mainly from the mountainous regions of Asia Minor, Persia, the Caucasus, Turkey and Bukhara.",
    ],
    "girasol":[
         "The sunflower has a robust, upright stem, with hairs and large oval leaves.",
         "The flower of the sunflower can measure between 5 and 40 centimeters across.",
  
    ],

}
//---------------------------------------------significado ingles---------------------------------------------------------------------------------------------------------------------------------
const SignificadoEnglish = {
    "rosa": [
         "The rose symbol of sympathy, frankness and kindness.",
         "Symbolize appreciation, trust and gratitude",
    ],
    "tulipan": [
       "The tulip is a symbol of sincere love.",
       "It is the meaning of affection, joy",
        
    ],
    "girasol":[
         "The sunflower is the symbol of the Sun and symbolizes love and admiration",
         "The sunflower means happiness, vitality, positivism and energy",
  
    ],

}
//-----------------------------------------apl--------------------------------------------------------------------------------------------------------------------------
const createDirectivePayload = (aplDocumentId, dataSources = {}, tokenId = "documentToken") => {
    return {
        type: "Alexa.Presentation.APL.RenderDocument",
        token: tokenId,
        document: {
            type: "Link",
            src: "doc://alexa/apl/documents/" + aplDocumentId
        },
        datasources: dataSources
    };
};
//----------------------------------------------------------------bienvenidad-----------------------------------------------------------------------------------------------------
const LaunchRequestHandler = {
  canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
  },
  handle(handlerInput) {
    const { attributesManager } = handlerInput;
    const requestAttributes = attributesManager.getRequestAttributes();
    const sessionAttributes = attributesManager.getSessionAttributes();

 
    const name = sessionAttributes['nombre'];
    const nombre = name.charAt(0).toUpperCase() + name.slice(1);
    const significado = sessionAttributes['significado'];

    const encabezado = requestAttributes.t('TITLE');
    const by = requestAttributes.t('BY');
    const titulo = requestAttributes.t('T_WELCOME');
    let speakOutput = requestAttributes.t('WELCOME_MESSAGE');
    const footer = requestAttributes.t('FOOTER');

    if ((name !== undefined && name !== null) ||(significado !== undefined && significado !== null)) {
      speakOutput = requestAttributes.t('WELCOME_DATA', nombre, significado);
    } else if (name === undefined && significado === undefined) {
      speakOutput = requestAttributes.t('WELCOME_MESSAGE');
    } else if (name === undefined) {
      speakOutput = requestAttributes.t('WELCOME_NO_NAME', significado);
    } else if (significado === undefined) {
      speakOutput = requestAttributes.t('WELCOME_NO_FLOR', nombre);
    }

    infoSources.encabezado = encabezado;
    infoSources.by = by;
    infoSources.titulo = titulo;
    infoSources.msj = speakOutput;
    infoSources.footer = footer;
    

    if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      DOCUMENT_ID = "bienvenida";
      const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
      handlerInput.responseBuilder.addDirective(aplDirective);
    }

    return handlerInput.responseBuilder
      .speak(speakOutput)
      .reprompt(speakOutput)
      .getResponse();
  }
};

//------------------------------------------------------descripcion español---------------------------------------------------------------------------------------------------
const CuriosidadfloresIntent = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CuriosidadfloresIntent';
    },
    handle(handlerInput) {
        const { flor } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (flor && DescripcionTable[flor.value]) {
            let descriptions = DescripcionTable[flor.value];
            let randomIndex = Math.floor(Math.random() * descriptions.length);
            let description = descriptions[randomIndex];
            speakOutput = requestAttributes.t('FLORES', flor.value, description);
            speechText = requestAttributes.t('FLORES', flor.value, description);
        
            if (description === "Rosa. Es un género que está compuesto por un conocido grupo de arbustos espinosos y floridos representantes principales de la familia de las rosáceas."){
                
                const encabezado = requestAttributes.t('TITLE');
                 const by = requestAttributes.t('BY');
                 const titulo = requestAttributes.t('ROSA');
                 let speakOutput = requestAttributes.t('ROSA1');
                 const footer = requestAttributes.t('FOOTER');
                
                 infoSources.encabezado = encabezado;
                 infoSources.by = by;
                 infoSources.titulo = titulo;
                 infoSources.msj = speakOutput;
                 infoSources.footer = footer;
                
                 DOCUMENT_ID = "rosasignificado";
                 if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                     const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                     handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description ===  "El rosal es una de las plantas más populares de los jardines, incluso existen jardines específicos llamados rosaledas"){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('ROSA');
                let speakOutput = requestAttributes.t('ROSA2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "rosasignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
           
            }else if(description ===  "Tulipa es un género de plantas perennes y bulbosas perteneciente a la familia Liliaceae, en el que se incluyen los populares tulipanes"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "El género Tulipa comprende aproximadamente unas 150 especies originarias, principalmente de las regiones montañosas de Asia Menor, Persia, el Cáucaso, Turquía y Bukhara."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "El girasol tiene un tallo robusto, erguido, con pelitos y hojas ovaladas de gran tamaño"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "La flor del girasol puede medir entre 5 y 40 centímetros de ancho"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('INFORMACION_NOFOUND');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('INFORMACION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    
}
    
};
//------------------------------------------------------significado español-------------------------------------------------------------------------------------------------
const SignificadofloresIntent = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'SignificadofloresIntent';
    },
    handle(handlerInput) {
        const { flor } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (flor && SignificadoTable[flor.value]) {
            let meanings = SignificadoTable[flor.value];
            let randomIndex = Math.floor(Math.random() * meanings.length);
            let meaning = meanings[randomIndex];
            speakOutput = requestAttributes.t('FLORES', flor.value, meaning);
            speechText = requestAttributes.t('FLORES', flor.value, meaning);
        
            if (meaning === "La rosa símbolo de simpatía, franqueza y amabilidad."){
                
                const encabezado = requestAttributes.t('TITLE');
                 const by = requestAttributes.t('BY');
                 const titulo = requestAttributes.t('ROSA');
                 let speakOutput = requestAttributes.t('ROSA3');
                 const footer = requestAttributes.t('FOOTER');
                
                 infoSources.encabezado = encabezado;
                 infoSources.by = by;
                 infoSources.titulo = titulo;
                 infoSources.msj = speakOutput;
                 infoSources.footer = footer;
                
                 DOCUMENT_ID = "rosasignificado";
                 if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                     const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                     handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "Simbolizar aprecio, confianza y agradecimiento"){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('ROSA');
                let speakOutput = requestAttributes.t('ROSA4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "rosasignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
           
            }else if(meaning === "El tulipán es un símbolo de amor sincero."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning ===  "Es el significado del afecto, alegría."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "El girasol es el símbolo del Sol y simboliza el amor y la admiración"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "El girasol significa la felicidad, la vitalidad, el positivismo y la energía"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('INFORMACION_NOFOUND');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('INFORMACION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    
}
    
};
//------------------------------------------------------descripcion ingles---------------------------------------------------------------------------------------------------

const CuriosityFlowersIntent = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'CuriosityFlowersIntent';
    },
    handle(handlerInput) {
        const { flor } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (flor && DescriptionEnglish[flor.value]) {
            let descriptions = DescriptionEnglish[flor.value];
            let randomIndex = Math.floor(Math.random() * descriptions.length);
            let description = descriptions[randomIndex];
            speakOutput = requestAttributes.t('FLORES', flor.value, description);
            speechText = requestAttributes.t('FLORES', flor.value, description);
        
            if (description === "Rosa. It is a genus that is made up of a well-known group of thorny and flowering shrubs that are the main representatives of the Rosaceae family."){
                
                const encabezado = requestAttributes.t('TITLE');
                 const by = requestAttributes.t('BY');
                 const titulo = requestAttributes.t('ROSA');
                 let speakOutput = requestAttributes.t('ROSA1');
                 const footer = requestAttributes.t('FOOTER');
                
                 infoSources.encabezado = encabezado;
                 infoSources.by = by;
                 infoSources.titulo = titulo;
                 infoSources.msj = speakOutput;
                 infoSources.footer = footer;
                
                 DOCUMENT_ID = "rosasignificado";
                 if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                     const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                     handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description ===  "The rose bush is one of the most popular plants in gardens, there are even specific gardens called rose gardens"){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('ROSA');
                let speakOutput = requestAttributes.t('ROSA2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "rosasignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
           
            }else if(description ===  "Tulipa is a genus of perennial and bulbous plants belonging to the Liliaceae family, which includes the popular tulips"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "The genus Tulipa comprises approximately 150 species originating mainly from the mountainous regions of Asia Minor, Persia, the Caucasus, Turkey and Bukhara."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "Sunflower has a robust, erect stem, with hairs and large oval leavesn"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL_1');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(description === "The sunflower flower can measure between 5 and 40 centimeters wide"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL_2');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('INFORMACION_NOFOUND');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('INFORMACION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    
}
    
};
//------------------------------------------------------significado ingles-------------------------------------------------------------------------------------------------
const MeaningFlowersIntent = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MeaningFlowersIntent';
    },
    handle(handlerInput) {
        const { flor } = handlerInput.requestEnvelope.request.intent.slots;
        const { attributesManager } = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        
        let speakOutput = "";
        let speechText;
        
        if (flor && SignificadoEnglish[flor.value]) {
            let meanings = SignificadoEnglish[flor.value];
            let randomIndex = Math.floor(Math.random() * meanings.length);
            let meaning = meanings[randomIndex];
            speakOutput = requestAttributes.t('FLORES', flor.value, meaning);
            speechText = requestAttributes.t('FLORES', flor.value, meaning);
        
            if (meaning === "The rose symbol of sympathy, frankness and kindness."){
                
                const encabezado = requestAttributes.t('TITLE');
                 const by = requestAttributes.t('BY');
                 const titulo = requestAttributes.t('ROSA');
                 let speakOutput = requestAttributes.t('ROSA3');
                 const footer = requestAttributes.t('FOOTER');
                
                 infoSources.encabezado = encabezado;
                 infoSources.by = by;
                 infoSources.titulo = titulo;
                 infoSources.msj = speakOutput;
                 infoSources.footer = footer;
                
                 DOCUMENT_ID = "rosasignificado";
                 if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                     const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                     handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "Symbolize appreciation, trust and gratitude"){
               
                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('ROSA');
                let speakOutput = requestAttributes.t('ROSA4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "rosasignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
           
            }else if(meaning === "The tulip is a symbol of sincere love.."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning ===  "It is the meaning of affection, joy."){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('TULIPAN');
                let speakOutput = requestAttributes.t('TULIPAN4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "tulipanessignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "The sunflower is the symbol of the Sun and symbolizes love and admiration"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL3');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }else if(meaning === "The sunflower means happiness, vitality, positivism and energy"){

                const encabezado = requestAttributes.t('TITLE');
                const by = requestAttributes.t('BY');
                const titulo = requestAttributes.t('GIRASOL');
                let speakOutput = requestAttributes.t('GIRASOL4');
                const footer = requestAttributes.t('FOOTER');
                
                infoSources.encabezado = encabezado;
                infoSources.by = by;
                infoSources.titulo = titulo;
                infoSources.msj = speakOutput;
                infoSources.footer = footer;
                
                DOCUMENT_ID = "girasolsignificado";
                if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                    const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                    handlerInput.responseBuilder.addDirective(aplDirective);
                }
            }

        } else {
            speechText = requestAttributes.t('INFORMACION_NOFOUND');
            
            const encabezado = requestAttributes.t('TITLE');
            const by = requestAttributes.t('BY');
            const titulo = requestAttributes.t('T_RECOMENDATION_NOFOUND');
            let speakOutput = requestAttributes.t('INFORMACION_NOFOUND');
            const footer = requestAttributes.t('FOOTER');
            
            infoSources.encabezado = encabezado;
            infoSources.by = by;
            infoSources.titulo = titulo;
            infoSources.msj = speakOutput;
            infoSources.footer = footer;
            
            DOCUMENT_ID = "bienvenida";
            if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
                const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
                handlerInput.responseBuilder.addDirective(aplDirective);
            }
        }
    
        const repromptOutput = requestAttributes.t('OTHER_RECOMENDATION');
        
        return handlerInput.responseBuilder
            .speak(speechText + repromptOutput ) ////speechText
            .reprompt(speechText + repromptOutput)
            .withShouldEndSession(false)
            .getResponse();
    
}
    
};
//-------------------------------------------------------------------------------------------------------------------------------------------------------
const significadoflorIntent = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'significadoflorIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        const sessionAttributes = attributesManager.getSessionAttributes();
        const slots = handlerInput.requestEnvelope.request.intent.slots;

        let name = slots.name.value;
        const significado = slots.significado.value;

        if(name === '' || name === null || name === undefined){
            name = sessionAttributes['nombre'];
        }else{
            sessionAttributes['nombre'] = name;
        }
        
        sessionAttributes['significado'] = significado;
        
        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_REG');
        let speechText = requestAttributes.t('LOAD_DATA', name, significado);
        
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speechText;

       if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
      DOCUMENT_ID = "bienvenida";
      const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
      handlerInput.responseBuilder.addDirective(aplDirective);
    }
        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .withShouldEndSession(false)
            .getResponse();
    }
};


//_____________________________________________MARCO LEGAL____________________________________________________________

const MarcoLegalIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'MarcoLegalIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('MSG_T_MARCO');
        const speakOutput = requestAttributes.t('MSG_MARCO');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
           DOCUMENT_ID = "marcolegal";
           const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
           handlerInput.responseBuilder.addDirective(aplDirective);
        }


        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
};

//------------------------------------------AYUDA------------------------------------------------------

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        
        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_HELP');
        const speakOutput = requestAttributes.t('HELP');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Ayuda";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .withShouldEndSession(false)
            .getResponse();
    }
};
//------------------------------SALIDA--------------------------------------------------------------
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const encabezado = requestAttributes.t('TITLE');
        const by = requestAttributes.t('BY');
        const titulo = requestAttributes.t('T_CANCEL');
        const speakOutput = requestAttributes.t('CANCEL');
        
        infoSources.encabezado = encabezado;
        infoSources.by = by;
        infoSources.titulo = titulo;
        infoSources.msj = speakOutput;
        
        if (Alexa.getSupportedInterfaces(handlerInput.requestEnvelope)['Alexa.Presentation.APL']) {
            DOCUMENT_ID = "Cancelar";
            const aplDirective = createDirectivePayload(DOCUMENT_ID, DataSource);
            handlerInput.responseBuilder.addDirective(aplDirective);
        }

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .withShouldEndSession(true)
            .getResponse();
    }
};
//-----------------------------ERROR-------------------------------------------------------------------------------
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();

        const speakOutput = requestAttributes.t('FALLBACK');

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        return handlerInput.responseBuilder.getResponse();
    }
};

const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const {attributesManager} = handlerInput;
        const requestAttributes = attributesManager.getRequestAttributes();
        
        const speakOutput = requestAttributes.t('ERROR_HANDLER');
        infoSources.msj = speakOutput;

        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};


// FUNCIONES PARA TRADUCIR
const LoggingRequestInterceptor = {
    process(handlerInput) {
        console.log(`Incoming request: ${JSON.stringify(handlerInput.requestEnvelope.request)}`);
    }
};

const LoggingResponseInterceptor = {
    process(handlerInput, response) {
      console.log(`Outgoing response: ${JSON.stringify(response)}`);
    }
};

const LocalizationRequestInterceptor = {
  process(handlerInput) {
    const localizationClient = i18n.use(sprintf).init({
      lng: handlerInput.requestEnvelope.request.locale,
      overloadTranslationOptionHandler: sprintf.overloadTranslationOptionHandler,
      resources: info,
      returnObjects: true
    });
    const attributes = handlerInput.attributesManager.getRequestAttributes();
    attributes.t = function (...args) {
      return localizationClient.t(...args);
    }
  }
};

//FUNCIONES PARA VERIFICAR Y GUARDAR DATOS DE LA SESIÓN
const LoadAttributesRequestInterceptor = {
    async process(handlerInput) {
        if(handlerInput.requestEnvelope.session['new']){
            const {attributesManager} = handlerInput;
            const persistentAttributes = await attributesManager.getPersistentAttributes() || {};
            handlerInput.attributesManager.setSessionAttributes(persistentAttributes);
        }
    }
};

const SaveAttributesResponseInterceptor = {
    async process(handlerInput, response) {
        const {attributesManager} = handlerInput;
        const sessionAttributes = attributesManager.getSessionAttributes();
        const shouldEndSession = (typeof response.shouldEndSession === "undefined" ? true : response.shouldEndSession);
        if(shouldEndSession || handlerInput.requestEnvelope.request.type === 'SessionEndedRequest') {       
            attributesManager.setPersistentAttributes(sessionAttributes);
            await attributesManager.savePersistentAttributes();
        }
    }
};


exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        CuriosidadfloresIntent,
        SignificadofloresIntent,
        CuriosityFlowersIntent,
        significadoflorIntent,
        MarcoLegalIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .addRequestInterceptors(
        LocalizationRequestInterceptor,
        LoggingRequestInterceptor,
        LoadAttributesRequestInterceptor)
    .addResponseInterceptors(
        LoggingResponseInterceptor,
        SaveAttributesResponseInterceptor)
    .withPersistenceAdapter(persistence.getPersistenceAdapter())
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda();